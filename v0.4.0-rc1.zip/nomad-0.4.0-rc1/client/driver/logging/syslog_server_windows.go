package logging

type SyslogServer struct {
}

func (s *SyslogServer) Shutdown() {
}

type SyslogMessage struct {
}
