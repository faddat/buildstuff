package structs

//go:generate codecgen -o structs.generated.go structs.go
