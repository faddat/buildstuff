package types

type PeriodicCallback func() error
