package main

// This file is intentionally empty to force early versions of Go
// to test compilation for tests.
